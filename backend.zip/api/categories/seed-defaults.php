<?php
require_once __DIR__ . '/../../backend/api/categories/seed-defaults.php';

